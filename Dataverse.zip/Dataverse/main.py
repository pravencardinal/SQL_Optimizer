
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
import os
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from query_api_v2 import router as query_router

app = FastAPI(title="Dataverse AI")
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
def ui(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


app.include_router(query_router)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8081))
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port
    )
