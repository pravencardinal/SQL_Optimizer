
from datasets import DATASETS

def get_tables(dataset: str) -> list[str]:
    """
    Return only the whitelisted fully-qualified table name(s) for the selected dataset.
    """
    if dataset not in DATASETS:
        raise ValueError(f"Unknown dataset: {dataset}")
    return [DATASETS[dataset]["table_fqdn"]]


