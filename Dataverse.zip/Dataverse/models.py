from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal

class QueryRequest(BaseModel):
    conversation_id: Optional[str] = None
    question: str = Field(..., min_length=3)
    model: Literal["flash", "pro"] = "flash"
    dataset: Literal["IQVIA", "SG2", "Clarivate"]



class QueryResponse(BaseModel):
    type: Literal["sql", "text", "both", "error"]
    sql: Optional[str] = None
    rows: Optional[List[Dict[str, Any]]] = None
    answer: Optional[str] = None
    error: Optional[str] = None

