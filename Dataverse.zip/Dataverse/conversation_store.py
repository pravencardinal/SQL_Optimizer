# conversation_store.py
from collections import deque
from typing import Deque, Dict, Any

_STORE: Dict[str, Deque[Dict[str, Any]]] = {}
MAX_TURNS = 12   # last 12 turns; tweak as needed

def get_history(conv_id: str) -> Deque[Dict[str, Any]]:
    return _STORE.setdefault(conv_id, deque(maxlen=MAX_TURNS))

def add_turn(conv_id: str, turn: Dict[str, Any]):
    get_history(conv_id).append(turn)

def history_as_text(conv_id: str, last_k: int = 6) -> str:
    hist = list(get_history(conv_id))[-last_k:]
    lines = []
    for t in hist:
        lines.append(f"User: {t['question']}")
        if t.get("answer"):
            lines.append(f"Assistant: {t['answer'][:200]}...")
        if t.get("sql"):
            lines.append(f"Assistant-SQL: {t['sql'][:200]}...")
    return "\n".join(lines)