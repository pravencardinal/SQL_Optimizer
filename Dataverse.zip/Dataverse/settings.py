
import os

# ===== Environment =====
LOCAL_MODE = os.getenv("LOCAL_MODE", "true").lower() == "false"

# ===== GCP Settings (used only when LOCAL_MODE = False) =====
PROJECT_ID = "cdejam-dataverse-ext-cah"
VERTEX_LOCATION = "us-central1"
BQ_PROJECT_ID = "cdejam-dataverse-ext-cah"


MODEL_MAP = {
    "flash": "gemini-2.5-flash",
    "pro": "gemini-2.5-pro",
}
