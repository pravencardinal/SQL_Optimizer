DATASETS = {
    "IQVIA": {
        "table_fqdn": "cdejam-dataverse-ext-cah.dataverse.D0_CARDINAL_IQVIA_DATA"
    },
    "SG2": {
        "table_fqdn": "cdejam-dataverse-ext-cah.dataverse.D0_CARDINAL_SG2_DATA"
    },
    "Clarivate": {
        "table_fqdn": "cdejam-dataverse-ext-cah.dataverse.D0_CARDINAL_CLARIVATE_DATA"
    },
}
