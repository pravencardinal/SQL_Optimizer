
from settings import LOCAL_MODE
import pandas as pd

if not LOCAL_MODE:
    from google.cloud import bigquery
    from settings import BQ_PROJECT_ID
    client = bigquery.Client(project=BQ_PROJECT_ID)

def run_query(sql: str):
    if LOCAL_MODE:
        return pd.DataFrame([
            {"metric": "Sample metric A", "value": 123},
            {"metric": "Sample metric B", "value": 456},
        ])

    job = client.query(sql)
    return job.result().to_dataframe()
