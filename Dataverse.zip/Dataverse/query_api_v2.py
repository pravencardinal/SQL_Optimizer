# query_api_v2.py

from fastapi import APIRouter
from router_service import get_tables
from gemini_service import decide_output_plan, clean_sql
from bigquery_service import run_query
from models import QueryRequest, QueryResponse

import re
import json
import pandas as pd
from pathlib import Path

# --- Conversation memory (you created conversation_store.py) ---
from conversation_store import add_turn, history_as_text
import time

router = APIRouter(prefix="/query", tags=["query"])

BOOT_BANNER = f"[ROUTER V2] loaded from {Path(__file__).resolve()}"
print(BOOT_BANNER)  # printed once on server startup


# -----------------------------
# Guardrails & small utilities
# -----------------------------
def sanitize_sql(sql: str, max_default: int = 2000) -> str:
    """
    Guardrails for LLM-generated SQL:
      - only single SELECT
      - forbid DDL/DML/EXPORT/metadata
      - enforce LIMIT if missing
    """
    s = (sql or "").strip().rstrip(";")
    lowered = s.lower()

    if not lowered.startswith("select"):
        raise ValueError("Only SELECT statements are allowed.")

    forbidden = (" insert ", " update ", " delete ", " create ",
                 " export ", " truncate ", " merge ", ";")
    if any(tok in lowered for tok in forbidden):
        raise ValueError("Statement contains forbidden keywords.")

    if "information_schema." in lowered or "pg_" in lowered or "sys." in lowered:
        raise ValueError("Access to metadata/system tables is not allowed.")

    # add a LIMIT if one not present
    if not re.search(r"\blimit\s+\d+\b", lowered):
        s += f" LIMIT {max_default}"

    return s


# friendly qualitative words -> small LIMIT values
QUAL_WORD_MAP = {
    "couple": 2,      # "a couple of rows"
    "few": 5,         # "a few rows"
    "several": 7,     # "several rows"
    "some": 5,        # "some rows"
}

def extract_requested_limit(question: str, default: int = 5, cap: int = 50) -> int:
    """
    Understand numeric and qualitative asks:
      - "with 3 rows", "show 7", "first 5", "top 10"
      - "a few rows", "a couple of rows", "several rows"
    """
    if not question:
        return default

    q = question.lower()

    # numeric patterns
    m = re.search(r"(?:with|show|first|top)\s+(\d{1,3})\s*(?:row|rows)?", q)
    if m:
        try:
            n = int(m.group(1))
            return max(1, min(n, cap))
        except Exception:
            pass  # fall through to qualitative

    # qualitative words
    for word, n in QUAL_WORD_MAP.items():
        if re.search(rf"\b(?:a\s+)?{word}\b\s*(?:row|rows)?", q):
            return min(n, cap)

    return default


def safe_preview_sql(table_fqdn: str, limit: int) -> str:
    """A guaranteed-valid preview SQL the app can always execute."""
    return f"SELECT * FROM `{table_fqdn}` LIMIT {limit}"


def is_unrecognized_name_error(err: Exception) -> bool:
    """
    Detect BigQuery's 'Unrecognized name' / 'Unrecognized field' failures
    (typical when an LLM hallucinates columns).
    """
    text = str(err).lower()
    return ("unrecognized name" in text) or ("unrecognized field" in text)


# -----------------------------
# Human-friendly summaries
# -----------------------------
def brief_df_summary(df: pd.DataFrame, max_cols_list: int = 6) -> str:
    """
    Clean, bullet-styled brief summary in Markdown.
    Never throws—even if df is empty.
    """
    if df is None or getattr(df, "empty", True):
        return (
            "### Dataset Summary\n"
            "- No rows returned in preview.\n"
            "- Try applying a filter (date, product class, manufacturer) for better results.\n"
        )

    n_rows, n_cols = df.shape
    cols = list(df.columns)

    # light type inference
    num_cols, text_cols = [], []
    for c in cols:
        try:
            if pd.api.types.is_numeric_dtype(df[c]):
                num_cols.append(c)
            else:
                text_cols.append(c)
        except Exception:
            text_cols.append(c)

    out = []
    out.append(f"### Dataset Summary (preview of {n_rows} rows)")
    out.append(f"- **Total fields:** {n_cols}")
    out.append("- **Overview:** Mix of facility descriptors, product attributes, classification tags, and spend/volume metrics.")

    if text_cols:
        key_text = ", ".join(text_cols[:max_cols_list])
        out.append(f"- **Key categorical fields:** {key_text}")

    if num_cols:
        key_num = ", ".join(num_cols[:max_cols_list])
        out.append(f"- **Key numeric fields:** {key_num}")

    # tiny exemplar
    try:
        first_cat = next((c for c in text_cols if df[c].notna().any()), None)
        if first_cat:
            sample_vals = (
                df[first_cat].astype(str)
                .value_counts(dropna=True)
                .head(2)
                .index.tolist()
            )
            if sample_vals:
                out.append(f"- **Observed pattern:** `{first_cat}` shows values such as {', '.join(sample_vals)}")
    except Exception:
        pass

    out.append("- **Next steps:** Request trends, top‑N rankings, filters (manufacturer, specialty, date range), or deeper segmentation.")
    return "\n".join(out)


def detailed_df_summary(df: pd.DataFrame) -> str:
    """
    A more descriptive, sectioned Markdown summary.
    Never throws—even if df is empty.
    """
    if df is None or getattr(df, "empty", True):
        return (
            "### Detailed Dataset Overview\n"
            "- No rows available in the preview.\n"
            "- Try a time filter, product class, manufacturer, or facility constraint.\n"
        )

    n_rows, n_cols = df.shape
    cols = list(df.columns)

    num_cols, text_cols = [], []
    for c in cols:
        try:
            if pd.api.types.is_numeric_dtype(df[c]):
                num_cols.append(c)
            else:
                text_cols.append(c)
        except Exception:
            text_cols.append(c)

    lines = []
    lines.append(f"### Detailed Dataset Overview ({n_rows} row preview)")
    lines.append(
        f"\nThis dataset includes **{n_rows} rows** and **{n_cols} fields**, representing "
        f"facility identifiers, product details, UNSPSC classifications, and financial/spend indicators."
    )

    if text_cols:
        lines.append("\n#### Key Text / Categorical Columns")
        for c in text_cols[:10]:
            lines.append(f"- **{c}**")

    if num_cols:
        lines.append("\n#### Key Numeric Columns")
        for c in num_cols[:10]:
            lines.append(f"- **{c}**")

    # observed patterns
    try:
        first_cat = next((c for c in text_cols if df[c].notna().any()), None)
        if first_cat:
            sample_vals = df[first_cat].astype(str).value_counts().head(5).index.tolist()
            lines.append("\n#### Observed Patterns")
            lines.append(f"- `{first_cat}` frequently appears as: {', '.join(sample_vals)}")
    except Exception:
        pass

    lines.append("\n#### What You Can Do Next")
    lines.append("- Request trends over time")
    lines.append("- Compare facilities or manufacturers")
    lines.append("- Analyze spend distributions and variance")
    lines.append("- Produce top‑N product or supplier summaries")

    return "\n".join(lines)


# -----------------------------
# Main route: Plan → Execute → Compose → Respond
# -----------------------------
@router.post("/", response_model=QueryResponse)
def query(req: QueryRequest):
    try:
        print("[ROUTER V2] handling request...")  # visible per request

        # --- Resolve dataset to exactly one FQDN (whitelisted table) ---
        tables = get_tables(req.dataset)
        table_fqdn = tables[0]

        # --- Conversation context (NEW): build a context-aware question for the planner ---
        conv_id = req.conversation_id or f"conv_{int(time.time()*1000)}"
        hist_text = history_as_text(conv_id, last_k=6)
        planned_question = (
            f"Conversation so far:\n{hist_text}\n\n"
            f"Current user question:\n{req.question}"
        ).strip()

        # ---------------- 1) PLAN ----------------
        # (CHANGED) we now send planned_question (with history) instead of raw req.question
        plan = decide_output_plan(planned_question, tables, req.model)
        print("[ROUTER V2] PLAN:", json.dumps(plan, indent=2))

        mode = (plan.get("mode") or "text").lower()                 # "text" | "table" | "both"
        summary_style = (plan.get("summary_style") or "brief").lower()

        rows = None
        sql  = None
        df   = None

        table_spec = plan.get("table") or {}
        # narr_spec  = plan.get("narrative") or {}   # available if needed

        # ---------------- 2) EXECUTE ----------------
        # Extract a per-request LIMIT (supports "with 3 rows", "a few rows", ...)
        requested_limit = extract_requested_limit(req.question, default=5, cap=50)

        if mode == "table":
            raw_sql = clean_sql(table_spec.get("sql", ""))
            sql     = sanitize_sql(raw_sql, max_default=requested_limit)
            try:
                df = run_query(sql)
            except Exception as e:
                # If the LLM projected unknown columns, retry with a guaranteed-safe preview
                if is_unrecognized_name_error(e):
                    sql = safe_preview_sql(table_fqdn, requested_limit)
                    df  = run_query(sql)
                else:
                    raise
            rows = df.to_dict(orient="records")

        elif mode == "both":
            raw_sql = clean_sql(table_spec.get("sql", ""))
            sql     = sanitize_sql(raw_sql, max_default=requested_limit)
            try:
                df = run_query(sql)
            except Exception as e:
                if is_unrecognized_name_error(e):
                    sql = safe_preview_sql(table_fqdn, requested_limit)
                    df  = run_query(sql)
                else:
                    raise
            rows = df.to_dict(orient="records")

        elif mode == "text":
            # For text-only, we still get a small preview so summaries are robust (df is never None)
            preview_sql = safe_preview_sql(table_fqdn, requested_limit)
            df = run_query(preview_sql)

        # ---------------- 3) COMPOSE ----------------
        # Deterministic summary (no LLM): brief vs detailed based on summary_style
        answer = None
        if mode in ("text", "both"):
            if summary_style == "detailed":
                answer = detailed_df_summary(df)
            else:
                answer = brief_df_summary(df)

        # ---------------- 4) RESPOND ----------------
        # Build resp first so we can save it to conversation memory in one place
        if mode == "table" and rows is not None:
            resp = QueryResponse(type="sql", sql=sql, rows=rows)
        elif mode == "text":
            resp = QueryResponse(type="text", sql=None, answer=answer)
        elif mode == "both":
            resp = QueryResponse(type="both", sql=sql, rows=rows, answer=answer)
        else:
            # Fallbacks: prefer text if available, otherwise table
            if answer:
                resp = QueryResponse(type="text", sql=sql, answer=answer)
            elif rows is not None:
                resp = QueryResponse(type="sql", sql=sql, rows=rows)
            else:
                resp = QueryResponse(type="error", error="Planner returned no actionable outputs.")

        # --- Save this turn to memory (NEW) ---
        add_turn(conv_id, {
            "question": req.question,
            "dataset": req.dataset,
            "mode": resp.type,
            "sql": resp.sql,
            "answer": resp.answer
        })

        return resp

    except ValueError as ve:
        # Guardrails / dataset errors: return JSON (avoid raw 500)
        return QueryResponse(type="error", error=str(ve))
    except Exception as e:
        # Unexpected error → return JSON so UI shows a friendly banner
        return QueryResponse(type="error", error=f"{e.__class__.__name__}: {e}")